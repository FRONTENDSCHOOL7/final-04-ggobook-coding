import React from "react";
import User from "./User";

export default function Search() {
  return (
    <>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
      <User></User>
    </>
  );
}
