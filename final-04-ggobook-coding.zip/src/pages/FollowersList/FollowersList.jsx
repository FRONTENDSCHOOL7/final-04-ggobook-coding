import React from "react";
import Follower from "./Follower";

export default function FollowersList() {
  return (
    <>
      <Follower></Follower>
      <Follower></Follower>
      <Follower></Follower>
      <Follower></Follower>
      <Follower></Follower>
      <Follower></Follower>
      <Follower></Follower>
      <Follower></Follower>
      <Follower></Follower>
      <Follower></Follower>
    </>
  );
}
